package eggs.count;

public class numberofeggs {

	public static void main(String[] args) {
	calculateEggs eOb=new calculateEggs();
	eOb.setTotalEgg(500);
	eOb.calEggs();
	eOb.display();
	
	}

}
