package eggs.count;

public class calculateEggs {
	private int totalEgg;
	eggss a=new eggss();

	public void setTotalEgg(int totalEgg) {
		this.totalEgg = totalEgg;
	}
	public void calEggs(){
		a.setGross(totalEgg/144);
		totalEgg%=144;
		a.setDozen(totalEgg/12);
		totalEgg%=12;
		a.setRemaining(totalEgg);}
	
	public void display() {
		System.out.println("no of gross:"+a.getGross()+"\nno of dozen:" +a.getDozen() +"\nno of remaining:"+a.getRemaining());
	
}
}
