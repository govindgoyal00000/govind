package com.sujata.demo;
//Polymorphism
public class Shape {

	public void area(int length,int breadth) {
		int area=length*breadth;
		System.out.println("area of rec:" +area);}
	public void area(int side) {
		int area=side*side;
		System.out.println("Area of Square : "+area);
	}
	
	public void area(double radius) {
		double area=3.142*radius*radius;
		System.out.println("Area of Circle : "+area);
	}
	public void peri(int length,int breadth) {
		int peri=2*(length+breadth);
		System.out.println("peri of rec:" +peri);
	}
	public void peri(int side) {
		int peri=4*side;
		System.out.println("peri of square:" +peri);
	}
	
}