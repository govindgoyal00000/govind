package com.sujata.demo;

public class MainShape{

	public static void main(String[] args) {
		Shape shape=new Shape();

		shape.area(7, 5);
		shape.area(6.5);
		shape.area(8);
		shape.peri(4,5);
		shape.peri(5);
		}
}